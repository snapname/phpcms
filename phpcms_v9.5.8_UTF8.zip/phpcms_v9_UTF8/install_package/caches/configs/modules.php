<?php
return array (
  'member' => '会员',
  'vote' => '投票',
  'link' => '友情链接',
  'message' => '短消息',
  'announce' => '网站公告',
  'special' => '专题',
  'content' => '内容模块',
  'block' => '碎片',
  'comment' => '评论',
);
?>