<?php
return array(
	//站外视频上传接口地址
	'api_url' => 'http://juhe.gcvideo.cn/v5/api',
	'api' => 'http://juhe.gcvideo.cn/api/',
	'player_url' => 'http://player.juhe.gcvideo.cn/player.php/vid/', 
);
?>