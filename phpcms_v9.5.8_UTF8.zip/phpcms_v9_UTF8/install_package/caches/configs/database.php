<?php

return array (
	'default' => array (
		'hostname' => 'localhost',
		'database' => 'phpcms',
		'username' => '',
		'password' => '',
		'tablepre' => 'v9_',
		'charset' => 'utf8',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>