<?php
$LANG['add_keylink']				=	'Add related URLs';
$LANG['keylink_name']				=	'Keywords';
$LANG['link_address']				=	'Links';
?>